
import { User, UserStats } from '../types';

const USERS_KEY = 'codenames_users';
const SESSION_KEY = 'codenames_current_user';

const defaultStats: UserStats = {
  wins: 0,
  losses: 0,
  gamesPlayed: 0,
  winStreak: 0,
  bestStreak: 0,
  avgRoundsPerWin: 0
};

export const authService = {
  getCurrentUser: (): User | null => {
    const session = localStorage.getItem(SESSION_KEY);
    return session ? JSON.parse(session) : null;
  },

  login: (email: string): User => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    let user = users.find((u: User) => u.email === email);
    
    if (!user) {
      user = {
        id: Math.random().toString(36).substr(2, 9),
        username: email.split('@')[0],
        email,
        level: 1,
        stats: { ...defaultStats }
      };
      users.push(user);
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
    
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    return user;
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  },

  updateStats: (userId: string, isWin: boolean, turns: number) => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const userIndex = users.findIndex((u: User) => u.id === userId);
    
    if (userIndex !== -1) {
      const u = users[userIndex];
      u.stats.gamesPlayed++;
      if (isWin) {
        u.stats.wins++;
        u.stats.winStreak++;
        u.stats.bestStreak = Math.max(u.stats.winStreak, u.stats.bestStreak);
        // Simplified avg calculation
        u.stats.avgRoundsPerWin = (u.stats.avgRoundsPerWin * (u.stats.wins - 1) + turns) / u.stats.wins;
      } else {
        u.stats.losses++;
        u.stats.winStreak = 0;
      }
      users[userIndex] = u;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      
      const session = authService.getCurrentUser();
      if (session && session.id === userId) {
        localStorage.setItem(SESSION_KEY, JSON.stringify(u));
      }
    }
  }
};
