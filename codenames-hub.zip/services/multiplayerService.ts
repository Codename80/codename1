
import { GameState, SyncMessage, User } from '../types';

class MultiplayerService {
  private peer: any = null;
  private connections: any[] = [];
  private onStateUpdate: ((state: GameState) => void) | null = null;
  public isHost: boolean = false;
  private currentRoomCode: string = '';

  init(onStateUpdate: (state: GameState) => void) {
    this.onStateUpdate = onStateUpdate;
  }

  // Host a new room
  hostGame(roomCode: string, initialState: GameState) {
    this.isHost = true;
    this.currentRoomCode = roomCode;
    if (this.peer) this.peer.destroy();
    
    const Peer = (window as any).Peer;
    this.peer = new Peer(`CODENAMES-HUB-${roomCode}`);

    this.peer.on('open', (id: string) => {
      console.log('[Host] Peer ID Registered:', id);
    });

    this.peer.on('connection', (conn: any) => {
      console.log('[Host] New client attempting connection...');
      
      conn.on('open', () => {
        console.log('[Host] Connection established with client');
        this.connections.push(conn);
        conn.send({ type: 'STATE_UPDATE', payload: initialState });
      });

      conn.on('data', (data: SyncMessage) => {
        console.log('[Host] Received data from client:', data.type);
        if (data.type === 'PLAYER_ACTION') {
          window.dispatchEvent(new CustomEvent('remote_action', { detail: data.payload }));
        }
      });

      conn.on('close', () => {
        this.connections = this.connections.filter(c => c !== conn);
        console.log('[Host] Client disconnected');
      });
    });

    this.peer.on('error', (err: any) => {
      console.error('[Host] Peer error:', err);
    });
  }

  // Join an existing room
  joinGame(roomCode: string, user: User): Promise<void> {
    return new Promise((resolve, reject) => {
      this.isHost = false;
      this.currentRoomCode = roomCode;
      
      if (this.peer) this.peer.destroy();
      const Peer = (window as any).Peer;
      this.peer = new Peer();

      this.peer.on('open', () => {
        console.log('[Client] Connecting to host: ', `CODENAMES-HUB-${roomCode}`);
        const conn = this.peer.connect(`CODENAMES-HUB-${roomCode}`, {
          reliable: true
        });
        
        conn.on('open', () => {
          this.connections = [conn];
          console.log('[Client] Connected to host. Sending JOIN handshake.');
          this.sendAction('JOIN', { user }, user.id);
          resolve();
        });

        conn.on('data', (data: SyncMessage) => {
          if (data.type === 'STATE_UPDATE' && this.onStateUpdate) {
            console.log('[Client] State update received from host');
            this.onStateUpdate(data.payload);
          }
        });

        conn.on('error', (err: any) => {
          console.error('[Client] Connection error:', err);
          reject(err);
        });

        setTimeout(() => {
          if (this.connections.length === 0) {
            reject('Connection timeout. The Room Code might be wrong or the host is offline.');
          }
        }, 8000);
      });

      this.peer.on('error', (err: any) => {
        console.error('[Client] Peer error:', err);
        reject(err);
      });
    });
  }

  broadcastState(state: GameState) {
    if (!this.isHost) return;
    this.connections.forEach(conn => {
      if (conn && conn.open) {
        conn.send({ type: 'STATE_UPDATE', payload: state });
      }
    });
  }

  sendAction(action: string, data: any, userId: string) {
    if (this.isHost) {
      return;
    }
    const hostConn = this.connections[0];
    if (hostConn && hostConn.open) {
      hostConn.send({ 
        type: 'PLAYER_ACTION', 
        payload: { action, data, userId } 
      });
    } else {
      console.warn('[Client] Cannot send action: No connection to host');
    }
  }

  disconnect() {
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }
    this.connections = [];
    this.isHost = false;
  }
}

export const multiplayerService = new MultiplayerService();
