
import { GameState, Team, Role, Card, User, GamePlayer, GameMessage, GameStatus, BotDifficulty } from '../types';
import { WORD_LIST_EN, WORD_LIST_CKB } from '../constants';

const GAMES_KEY = 'codenames_active_games';

const generateRoomCode = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

const shuffleArray = <T,>(array: T[]): T[] => {
  const newArr = [...array];
  for (let i = newArr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
  }
  return newArr;
};

const saveGame = (game: GameState) => {
  try {
    const games = JSON.parse(localStorage.getItem(GAMES_KEY) || '{}');
    games[game.roomCode.toUpperCase()] = game;
    localStorage.setItem(GAMES_KEY, JSON.stringify(games));
    window.dispatchEvent(new CustomEvent('game_update', { detail: game }));
  } catch (e) {
    console.error("Failed to save game state:", e);
  }
};

export const gameService = {
  getGame: (roomCode: string): GameState | null => {
    if (!roomCode) return null;
    try {
      const cleanCode = roomCode.trim().toUpperCase();
      const games = JSON.parse(localStorage.getItem(GAMES_KEY) || '{}');
      return games[cleanCode] || null;
    } catch (e) {
      console.error("Error reading games from storage:", e);
      return null;
    }
  },

  createGame: (creator: User, language: 'en' | 'ckb'): GameState => {
    const roomCode = generateRoomCode();
    const sourceList = language === 'ckb' ? WORD_LIST_CKB : WORD_LIST_EN;
    const words = shuffleArray(sourceList).slice(0, 25);
    
    const startsFirst = Team.RED;
    const redCount = 9;
    const blueCount = 8;
    
    const teams = [
      ...Array(redCount).fill(Team.RED),
      ...Array(blueCount).fill(Team.BLUE),
      ...Array(7).fill(Team.NEUTRAL),
      Team.ASSASSIN
    ];
    const shuffledTeams = shuffleArray(teams);
    
    const cards: Card[] = words.map((word, i) => ({
      id: `card-${i}`,
      word,
      team: shuffledTeams[i],
      isRevealed: false
    }));
    
    const initialPlayer: GamePlayer = {
      userId: creator.id,
      username: creator.username,
      team: null, // Start unassigned
      role: Role.SPECTATOR,
      isReady: false
    };

    const gameState: GameState = {
      roomId: Math.random().toString(36).substr(2, 9),
      roomCode,
      status: GameStatus.LOBBY,
      cards,
      turn: startsFirst,
      turnStartTime: Date.now(),
      winner: null,
      redScore: 0,
      blueScore: 0,
      totalRed: redCount,
      totalBlue: blueCount,
      players: [initialPlayer],
      messages: [{
        id: 'sys-1',
        senderId: 'system',
        senderName: 'System',
        senderRole: Role.SPECTATOR,
        text: `Room created. Code: ${roomCode}`,
        timestamp: Date.now(),
        isSystem: true
      }],
      guessesThisTurn: 0,
      isGameOver: false,
      creatorId: creator.id,
      language: language
    };

    saveGame(gameState);
    return gameState;
  },

  joinGame: (roomCode: string, user: User): GameState | null => {
    const cleanCode = roomCode.trim().toUpperCase();
    const game = gameService.getGame(cleanCode);
    if (!game) return null;
    
    if (!game.players.find((p: GamePlayer) => p.userId === user.id)) {
      game.players.push({
        userId: user.id,
        username: user.username,
        team: null,
        role: Role.SPECTATOR,
        isReady: false
      });
      game.messages.push({
        id: `sys-${Date.now()}`,
        senderId: 'system',
        senderName: 'System',
        senderRole: Role.SPECTATOR,
        text: `${user.username} infiltrated the room.`,
        timestamp: Date.now(),
        isSystem: true
      });
      saveGame(game);
    }
    
    return { ...game };
  },

  addBot: (roomCode: string, team: Team, role: Role, difficulty: BotDifficulty = BotDifficulty.AGENT): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    
    const botId = `bot-${Math.random().toString(36).substr(2, 5)}`;
    const botName = `AGENT_${botId.split('-')[1].toUpperCase()}`;
    
    game.players.push({
      userId: botId,
      username: botName,
      team: team,
      role: role,
      isReady: true,
      isBot: true,
      botDifficulty: difficulty
    });

    game.messages.push({
      id: `sys-bot-${Date.now()}`,
      senderId: 'system',
      senderName: 'System',
      senderRole: Role.SPECTATOR,
      text: `${botName} (${difficulty} AI) deployed to ${team}.`,
      timestamp: Date.now(),
      isSystem: true
    });

    saveGame(game);
    return { ...game };
  },

  updatePlayer: (roomCode: string, userId: string, updates: Partial<GamePlayer>): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    
    const pIdx = game.players.findIndex((p: GamePlayer) => p.userId === userId);
    if (pIdx !== -1) {
      game.players[pIdx] = { ...game.players[pIdx], ...updates };
      saveGame(game);
    }
    return { ...game };
  },

  startGame: (roomCode: string): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    game.status = GameStatus.PLAYING;
    game.guessesThisTurn = 0;
    game.turnStartTime = Date.now();
    game.messages.push({
      id: `sys-start-${Date.now()}`,
      senderId: 'system',
      senderName: 'System',
      senderRole: Role.SPECTATOR,
      text: `GRID INITIALIZED. ${game.turn} TEAM COMMENCING OPERATIONS.`,
      timestamp: Date.now(),
      isSystem: true
    });
    saveGame(game);
    return { ...game };
  },

  revealCard: (roomCode: string, cardId: string, userId: string): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    const card = game.cards.find(c => c.id === cardId);
    
    if (!card || card.isRevealed || game.isGameOver) return game;
    
    card.isRevealed = true;
    game.guessesThisTurn++;
    const player = game.players.find(p => p.userId === userId);
    
    game.messages.push({
      id: `reveal-${Date.now()}`,
      senderId: 'system',
      senderName: 'System',
      senderRole: Role.SPECTATOR,
      text: `${player?.username || 'Field Agent'} identified ${card.word} (${card.team})`,
      timestamp: Date.now(),
      isSystem: true
    });

    if (card.team === Team.RED) {
      game.redScore++;
      if (game.redScore === game.totalRed) {
        game.winner = Team.RED;
        game.isGameOver = true;
        game.status = GameStatus.ENDED;
      }
    } else if (card.team === Team.BLUE) {
      game.blueScore++;
      if (game.blueScore === game.totalBlue) {
        game.winner = Team.BLUE;
        game.isGameOver = true;
        game.status = GameStatus.ENDED;
      }
    } else if (card.team === Team.ASSASSIN) {
      game.winner = game.turn === Team.RED ? Team.BLUE : Team.RED;
      game.isGameOver = true;
      game.status = GameStatus.ENDED;
    }

    if (card.team !== game.turn) {
      game.turn = game.turn === Team.RED ? Team.BLUE : Team.RED;
      game.lastClue = undefined;
      game.guessesThisTurn = 0;
      game.turnStartTime = Date.now();
    }

    saveGame(game);
    return { ...game };
  },

  giveClue: (roomCode: string, word: string, count: number): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    game.lastClue = { word, count };
    game.guessesThisTurn = 0;
    // Turn does not change team, but shifts phase to operative, essentially same turn bucket but maybe we reset timer? 
    // Usually timer is per team turn. Let's keep timer running or reset. 
    // Standard rules: Timer is for the whole turn usually, or split. 
    // For simplicity, let's NOT reset start time here, as Spymaster+Operative share the team turn time often.
    // However, since bots have specific 3s constraint, we might want to refresh for the bot operative.
    // Let's reset to give Operative full time.
    game.turnStartTime = Date.now(); 
    
    game.messages.push({
      id: `clue-${Date.now()}`,
      senderId: 'system',
      senderName: 'System',
      senderRole: Role.SPYMASTER,
      text: `SIGNAL RECEIVED: ${word.toUpperCase()} (${count})`,
      timestamp: Date.now(),
      isSystem: true
    });
    saveGame(game);
    return { ...game };
  },

  sendMessage: (roomCode: string, message: GameMessage): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    game.messages.push(message);
    saveGame(game);
    return { ...game };
  },

  endTurn: (roomCode: string): GameState => {
    const game = gameService.getGame(roomCode);
    if (!game) throw new Error("Game not found");
    game.turn = game.turn === Team.RED ? Team.BLUE : Team.RED;
    game.lastClue = undefined;
    game.guessesThisTurn = 0;
    game.turnStartTime = Date.now();
    game.messages.push({
      id: `end-${Date.now()}`,
      senderId: 'system',
      senderName: 'System',
      senderRole: Role.SPECTATOR,
      text: `OPERATIONS HANDED OVER TO ${game.turn} TEAM.`,
      timestamp: Date.now(),
      isSystem: true
    });
    saveGame(game);
    return { ...game };
  }
};
