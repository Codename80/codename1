
import { GoogleGenAI, Type } from "@google/genai";
import { Card, Team } from "../types";

export const geminiService = {
  suggestClue: async (cards: Card[], targetTeam: Team, language: 'en' | 'ckb' = 'en'): Promise<{ word: string, count: number }> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const yourWords = cards.filter(c => c.team === targetTeam && !c.isRevealed).map(c => c.word);
    const opponentWords = cards.filter(c => c.team !== targetTeam && c.team !== Team.ASSASSIN && !c.isRevealed).map(c => c.word);
    const assassinWord = cards.find(c => c.team === Team.ASSASSIN)?.word || "";
    
    const langContext = language === 'ckb' 
      ? "You are playing in Kurdish (Sorani). Provide the clue word in Kurdish (Sorani)." 
      : "You are playing in English.";

    const prompt = `
      You are an expert Codenames Spymaster. ${langContext}
      Your team is: ${targetTeam}.
      Your words: ${yourWords.join(", ")}.
      Opponent words: ${opponentWords.join(", ")}.
      DANGEROUS ASSASSIN WORD: ${assassinWord}.

      Provide a single word clue that links 2 or more of your team's words without hitting opponent words or the assassin word.
      Return the result as JSON.
    `;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              word: { type: Type.STRING, description: "The single word clue." },
              count: { type: Type.NUMBER, description: "Number of related words." },
              reasoning: { type: Type.STRING, description: "Brief explanation." }
            },
            required: ["word", "count"]
          }
        }
      });

      const data = JSON.parse(response.text);
      return { word: data.word, count: data.count };
    } catch (error) {
      console.error("Gemini Clue Suggestion Error:", error);
      return { word: "HINT", count: 1 };
    }
  },

  guessCards: async (cards: Card[], clue: string, count: number): Promise<string[]> => {
     const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
     const unrevealedWords = cards.filter(c => !c.isRevealed).map(c => c.word);
     
     const prompt = `
      You are playing Codenames.
      Board words: ${unrevealedWords.join(", ")}.
      Clue provided: "${clue}" (Count: ${count}).
      
      Identify the ${count} words from the board that are most semantically related to the clue "${clue}".
      Return ONLY the array of words.
     `;

     try {
       const response = await ai.models.generateContent({
         model: "gemini-3-flash-preview",
         contents: prompt,
         config: {
           responseMimeType: "application/json",
           responseSchema: {
             type: Type.OBJECT,
             properties: {
               guesses: { 
                 type: Type.ARRAY, 
                 items: { type: Type.STRING },
                 description: "The list of words to guess." 
               }
             },
             required: ["guesses"]
           }
         }
       });

       const data = JSON.parse(response.text);
       return data.guesses || [];
     } catch (error) {
       console.error("Gemini Guess Error:", error);
       return unrevealedWords.slice(0, count);
     }
  }
};
