
import React, { useState, useEffect } from 'react';
import { User, GameState, GameStatus, Team, Role } from './types';
import { authService } from './services/authService';
import { gameService } from './services/gameService';
import { multiplayerService } from './services/multiplayerService';
import Navbar from './components/Navbar';
import Lobby from './components/Lobby';
import WaitingRoom from './components/WaitingRoom';
import GameView from './components/GameView';
import Profile from './components/Profile';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';

type View = 'AUTH' | 'HOME' | 'GAME' | 'PROFILE';

const AppContent: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<View>('AUTH');
  const [currentGame, setCurrentGame] = useState<GameState | null>(null);
  const [email, setEmail] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  const { t, language, setLanguage } = useLanguage();

  // 1. Session Restoration & P2P Init
  useEffect(() => {
    const session = authService.getCurrentUser();
    if (session) {
      setUser(session);
      setView('HOME');
    }
    
    multiplayerService.init((remoteState) => {
      console.log("[App] State update from host received");
      setCurrentGame(remoteState);
    });
  }, []);

  // 2. Broadcast State (Host Only)
  useEffect(() => {
    if (currentGame && user && multiplayerService.isHost) {
      multiplayerService.broadcastState(currentGame);
    }
  }, [currentGame]);

  // 3. Central Action Handler (The "Server" logic)
  const performAction = (action: string, data: any) => {
    if (!user || !currentGame) return;

    if (multiplayerService.isHost) {
      console.log(`[Host] Executing local action: ${action}`);
      let updated: GameState | null = null;
      try {
        switch (action) {
          case 'JOIN':
            updated = gameService.joinGame(currentGame.roomCode, data.user);
            break;
          case 'REVEAL':
            updated = gameService.revealCard(currentGame.roomCode, data.cardId, data.userId || user.id);
            break;
          case 'END_TURN':
            updated = gameService.endTurn(currentGame.roomCode);
            break;
          case 'GIVE_CLUE':
            updated = gameService.giveClue(currentGame.roomCode, data.word, data.count);
            break;
          case 'UPDATE_PLAYER':
            updated = gameService.updatePlayer(currentGame.roomCode, data.userId || user.id, data.updates);
            break;
          case 'START_GAME':
            updated = gameService.startGame(currentGame.roomCode);
            break;
          case 'SEND_MESSAGE':
            updated = gameService.sendMessage(currentGame.roomCode, data.message);
            break;
          case 'ADD_BOT':
            updated = gameService.addBot(currentGame.roomCode, data.team, data.role, data.difficulty);
            break;
        }
        if (updated) setCurrentGame({ ...updated });
      } catch (err) {
        console.error("[Host] Action execution failed:", err);
      }
    } else {
      console.log(`[Client] Requesting remote action: ${action}`);
      multiplayerService.sendAction(action, { ...data, userId: user.id }, user.id);
    }
  };

  useEffect(() => {
    const handleRemoteAction = (e: any) => {
      const { action, data, userId } = e.detail;
      performAction(action, { ...data, userId });
    };

    window.addEventListener('remote_action', handleRemoteAction);
    return () => window.removeEventListener('remote_action', handleRemoteAction);
  }, [currentGame, user]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    const user = authService.login(email);
    setUser(user);
    setView('HOME');
  };

  const handleLogout = () => {
    authService.logout();
    multiplayerService.disconnect();
    setUser(null);
    setView('AUTH');
    setCurrentGame(null);
  };

  const handleCreateGame = () => {
    if (!user) return;
    try {
      // Pass the current UI language as the game language preference
      const game = gameService.createGame(user, language);
      if (game) {
        multiplayerService.hostGame(game.roomCode, game);
        setCurrentGame(game);
        setView('GAME');
      }
    } catch (err) {
      console.error("Game creation failed", err);
    }
  };

  const handleJoinGame = async (code: string) => {
    if (!user) return;
    const sanitizedCode = code.trim().toUpperCase();
    setIsConnecting(true);
    try {
      await multiplayerService.joinGame(sanitizedCode, user);
      setView('GAME');
    } catch (err: any) {
      alert(err.toString());
    } finally {
      setIsConnecting(false);
    }
  };

  if (view === 'AUTH') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0f0f12] px-4">
        <div className="absolute top-6 right-6 z-20">
             <div className="flex bg-[#111111] rounded-lg border border-border-dark p-1">
                <button 
                  onClick={() => setLanguage('en')} 
                  className={`px-3 py-1.5 text-xs font-bold rounded transition-colors ${language === 'en' ? 'bg-primary text-white' : 'text-gray-500 hover:text-white'}`}
                >
                  EN
                </button>
                <button 
                  onClick={() => setLanguage('ckb')} 
                  className={`px-3 py-1.5 text-xs font-bold rounded transition-colors ${language === 'ckb' ? 'bg-primary text-white' : 'text-gray-500 hover:text-white'}`}
                >
                  کوردی
                </button>
             </div>
        </div>
        <div className="max-w-md w-full space-y-8 bg-surface-dark p-10 rounded-2xl border border-border-dark shadow-2xl relative z-10">
          <div className="text-center">
            <div className="mx-auto h-16 w-16 bg-primary rounded-xl flex items-center justify-center text-white mb-6">
              <span className="material-symbols-outlined text-4xl">extension</span>
            </div>
            <h2 className="text-3xl font-black text-white tracking-tight text-center uppercase">{t.login.title}</h2>
          </div>
          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="appearance-none rounded-lg block w-full px-4 py-3 border border-border-dark bg-[#181111] text-white placeholder-gray-600 focus:ring-primary focus:border-primary sm:text-sm font-medium"
              placeholder={t.login.placeholder}
            />
            <button
              type="submit"
              className="w-full py-3 px-4 border border-transparent text-sm font-black rounded-lg text-white bg-primary hover:bg-primary-dark transition-all shadow-lg shadow-primary/20 uppercase tracking-widest"
            >
              {t.login.button}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col font-display">
      <Navbar 
        user={user} 
        onLogout={handleLogout} 
        onNavigate={(v) => {
          if (v === 'HOME') {
            multiplayerService.disconnect();
            setCurrentGame(null);
          }
          setView(v);
        }} 
      />
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {isConnecting && (
          <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-md flex items-center justify-center">
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm font-black text-white uppercase tracking-[0.3em]">{t.login.connecting}</p>
            </div>
          </div>
        )}

        {view === 'HOME' && user && (
          <Lobby user={user} onCreateGame={handleCreateGame} onJoinGame={handleJoinGame} />
        )}
        
        {view === 'GAME' && user && (
          currentGame ? (
            <>
              {currentGame.status === GameStatus.LOBBY && (
                <WaitingRoom 
                  game={currentGame}
                  user={user}
                  onAction={performAction}
                />
              )}
              
              {(currentGame.status === GameStatus.PLAYING || currentGame.status === GameStatus.ENDED) && (
                <GameView 
                  game={currentGame} 
                  user={user} 
                  onAction={performAction}
                  onExit={() => {
                    multiplayerService.disconnect();
                    setView('HOME');
                    setCurrentGame(null);
                  }}
                />
              )}
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center space-y-4">
                <p className="text-gray-500 font-bold uppercase tracking-widest animate-pulse">{t.game.sync}</p>
                <p className="text-[10px] text-gray-700 uppercase tracking-widest">{t.game.waitingHost}</p>
              </div>
            </div>
          )
        )}

        {view === 'PROFILE' && user && <Profile user={user} />}
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
};

export default App;
