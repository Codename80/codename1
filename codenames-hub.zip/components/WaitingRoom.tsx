
import React, { useState } from 'react';
import { GameState, Team, Role, GamePlayer, User, BotDifficulty } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface WaitingRoomProps {
  game: GameState;
  user: User;
  onAction: (action: string, data: any) => void;
}

const MAX_BOTS_PER_TEAM = 2;

const WaitingRoom: React.FC<WaitingRoomProps> = ({ game, user, onAction }) => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<BotDifficulty>(BotDifficulty.AGENT);
  const { t } = useLanguage();
  const currentPlayer = game.players.find(p => p.userId === user.id);
  const isCreator = game.creatorId === user.id;

  const handleSetTeamRole = (team: Team | null, role: Role) => {
    onAction('UPDATE_PLAYER', { updates: { team, role } });
  };

  const handleToggleReady = () => {
    onAction('UPDATE_PLAYER', { updates: { isReady: !currentPlayer?.isReady } });
  };

  const handleStartGame = () => {
    onAction('START_GAME', {});
  };

  const handleSmartAddBot = (team: Team) => {
    const hasSpymaster = game.players.some(p => p.team === team && p.role === Role.SPYMASTER);
    const role = hasSpymaster ? Role.OPERATIVE : Role.SPYMASTER;
    onAction('ADD_BOT', { team, role, difficulty: selectedDifficulty });
  };

  const redPlayers = game.players.filter(p => p.team === Team.RED);
  const bluePlayers = game.players.filter(p => p.team === Team.BLUE);
  const unassigned = game.players.filter(p => p.team === null);

  const redSpymaster = redPlayers.find(p => p.role === Role.SPYMASTER);
  const blueSpymaster = bluePlayers.find(p => p.role === Role.SPYMASTER);
  
  const redBots = redPlayers.filter(p => p.isBot).length;
  const blueBots = bluePlayers.filter(p => p.isBot).length;

  const renderPlayerRow = (player: GamePlayer) => (
    <div key={player.userId} className="flex items-center justify-between p-3 bg-[#111111] border border-border-dark rounded-lg mb-2">
      <div className="flex items-center gap-3">
        <div className={`size-8 rounded-full bg-cover border-2 ${player.isReady ? 'border-green-500' : 'border-gray-700'} ${player.isBot ? 'ring-2 ring-blue-500/50 ring-offset-2 ring-offset-[#111111]' : ''}`} style={{ backgroundImage: `url(https://picsum.photos/seed/${player.userId}/100)` }} />
        <div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-bold text-white leading-none">{player.username}</p>
            {player.isBot && <span className={`text-[8px] border px-1 rounded font-black uppercase ${player.botDifficulty === BotDifficulty.ELITE ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : 'bg-blue-500/20 text-blue-400 border-blue-500/30'}`}>{player.botDifficulty}</span>}
          </div>
          <p className="text-[10px] text-gray-500 font-bold uppercase mt-1">{player.role}</p>
        </div>
      </div>
      {player.isReady && <span className="text-green-500 text-xs font-bold uppercase tracking-widest">Ready</span>}
    </div>
  );

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center">
      <div className="w-full max-w-4xl space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-black tracking-tight text-white uppercase italic">{t.waiting.title}</h1>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-surface-dark border border-border-dark shadow-inner">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{t.waiting.code}:</span>
            <span className="text-xl font-black text-primary tracking-[0.2em]">{game.roomCode}</span>
          </div>
        </div>

        {isCreator && (
          <div className="flex justify-center">
            <div className="bg-[#111111] border border-border-dark p-1 rounded-xl flex gap-1">
              {Object.values(BotDifficulty).map((diff) => (
                <button
                  key={diff}
                  onClick={() => setSelectedDifficulty(diff)}
                  className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${selectedDifficulty === diff ? 'bg-primary text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
                >
                  {diff} AI
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Red Team */}
          <div className="bg-[#1a0f0f] border border-red-900/30 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
                {t.waiting.redTeam} <span className="text-xs bg-red-500/10 px-2 py-0.5 rounded text-red-400 font-bold">{redPlayers.length}</span>
              </h2>
              {isCreator && (
                <button 
                  onClick={() => handleSmartAddBot(Team.RED)} 
                  disabled={redBots >= MAX_BOTS_PER_TEAM}
                  className="text-[10px] font-black text-gray-600 hover:text-red-500 uppercase tracking-tighter border border-border-dark px-2 py-1 rounded-md flex items-center gap-1 transition-all disabled:opacity-30 disabled:hover:text-gray-600 disabled:cursor-not-allowed"
                >
                  <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                  {redBots >= MAX_BOTS_PER_TEAM ? t.waiting.maxBots : t.waiting.addBot}
                </button>
              )}
            </div>
            <div className="space-y-2">
              {redPlayers.map(renderPlayerRow)}
              {redPlayers.length === 0 && <p className="text-center py-8 text-gray-600 italic text-sm">No agents assigned</p>}
            </div>
            <div className="mt-6 flex gap-2">
              <button 
                onClick={() => handleSetTeamRole(Team.RED, Role.SPYMASTER)}
                disabled={!!redSpymaster && currentPlayer?.role !== Role.SPYMASTER}
                className={`flex-1 py-3 rounded-xl border text-[10px] font-black tracking-widest transition-all uppercase disabled:opacity-30 ${currentPlayer?.team === Team.RED && currentPlayer.role === Role.SPYMASTER ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/40' : 'border-red-900/40 text-red-800 hover:bg-red-900/10'}`}
              >
                {t.waiting.joinSpy}
              </button>
              <button 
                onClick={() => handleSetTeamRole(Team.RED, Role.OPERATIVE)}
                className={`flex-1 py-3 rounded-xl border text-[10px] font-black tracking-widest transition-all uppercase ${currentPlayer?.team === Team.RED && currentPlayer.role === Role.OPERATIVE ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/40' : 'border-red-900/40 text-red-800 hover:bg-red-900/10'}`}
              >
                {t.waiting.joinOp}
              </button>
            </div>
          </div>

          {/* Blue Team */}
          <div className="bg-[#0f141a] border border-blue-900/30 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black text-blue-400 uppercase tracking-widest flex items-center gap-2">
                {t.waiting.blueTeam} <span className="text-xs bg-blue-500/10 px-2 py-0.5 rounded text-blue-400 font-bold">{bluePlayers.length}</span>
              </h2>
              {isCreator && (
                <button 
                  onClick={() => handleSmartAddBot(Team.BLUE)} 
                  disabled={blueBots >= MAX_BOTS_PER_TEAM}
                  className="text-[10px] font-black text-gray-600 hover:text-blue-400 uppercase tracking-tighter border border-border-dark px-2 py-1 rounded-md flex items-center gap-1 transition-all disabled:opacity-30 disabled:hover:text-gray-600 disabled:cursor-not-allowed"
                >
                  <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                  {blueBots >= MAX_BOTS_PER_TEAM ? t.waiting.maxBots : t.waiting.addBot}
                </button>
              )}
            </div>
            <div className="space-y-2">
              {bluePlayers.map(renderPlayerRow)}
              {bluePlayers.length === 0 && <p className="text-center py-8 text-gray-600 italic text-sm">No agents assigned</p>}
            </div>
            <div className="mt-6 flex gap-2">
              <button 
                onClick={() => handleSetTeamRole(Team.BLUE, Role.SPYMASTER)}
                disabled={!!blueSpymaster && currentPlayer?.role !== Role.SPYMASTER}
                className={`flex-1 py-3 rounded-xl border text-[10px] font-black tracking-widest transition-all uppercase disabled:opacity-30 ${currentPlayer?.team === Team.BLUE && currentPlayer.role === Role.SPYMASTER ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/40' : 'border-blue-900/40 text-blue-800 hover:bg-blue-900/10'}`}
              >
                {t.waiting.joinSpy}
              </button>
              <button 
                onClick={() => handleSetTeamRole(Team.BLUE, Role.OPERATIVE)}
                className={`flex-1 py-3 rounded-xl border text-[10px] font-black tracking-widest transition-all uppercase ${currentPlayer?.team === Team.BLUE && currentPlayer.role === Role.OPERATIVE ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/40' : 'border-blue-900/40 text-blue-800 hover:bg-blue-900/10'}`}
              >
                {t.waiting.joinOp}
              </button>
            </div>
          </div>
        </div>

        {unassigned.length > 0 && (
          <div className="bg-surface-dark border border-border-dark rounded-xl p-4">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">{t.waiting.unassigned}</h3>
            <div className="flex flex-wrap gap-3">
              {unassigned.map(p => (
                <div key={p.userId} className="flex items-center gap-2 px-3 py-1.5 bg-[#111111] rounded-full border border-border-dark">
                   <div className="size-4 rounded-full bg-cover" style={{ backgroundImage: `url(https://picsum.photos/seed/${p.userId}/100)` }} />
                   <span className="text-xs font-medium text-gray-300">{p.username}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-col items-center gap-4 pt-8 pb-12">
          <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
            <button
              onClick={handleToggleReady}
              className={`flex-1 max-w-[300px] h-14 rounded-xl text-lg font-black tracking-widest uppercase transition-all shadow-xl ${currentPlayer?.isReady ? 'bg-green-600 text-white' : 'bg-surface-dark border-2 border-border-dark text-gray-400 hover:text-white'}`}
            >
              {currentPlayer?.isReady ? t.waiting.ready : t.waiting.markReady}
            </button>

            {isCreator && (
              <button
                onClick={handleStartGame}
                disabled={game.players.length < 2 || !redSpymaster || !blueSpymaster}
                className="flex-1 max-w-[300px] h-14 rounded-xl bg-primary hover:bg-primary-dark text-white text-lg font-black tracking-widest uppercase transition-all shadow-xl shadow-primary/25 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                {(!redSpymaster || !blueSpymaster) ? t.waiting.needSpy : t.waiting.startGame}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WaitingRoom;
