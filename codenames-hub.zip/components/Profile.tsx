
import React from 'react';
import { User, MatchHistoryItem } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface ProfileProps {
  user: User;
}

const mockHistory: MatchHistoryItem[] = [
  { id: '1', result: 'VICTORY', score: '8-7', role: 'Red Operative', opponent: 'Blue Team', turns: 6, date: '2h ago' },
  { id: '2', result: 'DEFEAT', score: '5-8', role: 'Blue Spymaster', opponent: 'Red Team', turns: 8, date: 'Yesterday' },
  { id: '3', result: 'VICTORY', score: '9-8', role: 'Red Spymaster', opponent: 'Blue Team', turns: 9, date: '2 days ago' },
  { id: '4', result: 'VICTORY', score: 'Assassin', role: 'Blue Operative', opponent: 'Red Team', turns: 4, date: '3 days ago' },
];

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const { t } = useLanguage();

  return (
    <div className="max-w-5xl mx-auto w-full py-8 px-4 flex flex-col gap-8">
      <div className="w-full rounded-xl bg-surface-dark border border-border-dark p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between relative z-10">
          <div className="flex gap-6 items-center">
            <div 
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-xl size-24 ring-4 ring-[#181111]"
              style={{ backgroundImage: `url(https://picsum.photos/seed/${user.id}/200)` }}
            />
            <div className="flex flex-col gap-1">
              <h1 className="text-white text-3xl font-bold leading-tight tracking-tight">{user.username}</h1>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-yellow-500/10 text-yellow-500 border border-yellow-500/20">
                  <span className="material-symbols-outlined text-[14px] mr-1">military_tech</span>
                  Gold II
                </span>
                <span className="text-gray-600 text-sm">•</span>
                <span className="text-gray-400 text-sm font-normal">Level {user.level}</span>
              </div>
            </div>
          </div>
          <button className="px-6 py-2 rounded-lg bg-primary hover:bg-primary-dark text-white font-bold transition-all shadow-lg shadow-primary/20">
            {t.profile.edit}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-surface-dark rounded-xl p-6 border border-border-dark flex flex-col justify-between">
          <p className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-4">{t.profile.winRate}</p>
          <div className="flex items-center gap-4">
            <p className="text-white text-3xl font-black">62%</p>
            <div className="h-2 flex-1 bg-gray-800 rounded-full overflow-hidden">
              <div className="h-full bg-primary" style={{ width: '62%' }} />
            </div>
          </div>
        </div>
        <div className="bg-surface-dark rounded-xl p-6 border border-border-dark">
          <p className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-4">{t.profile.gamesPlayed}</p>
          <p className="text-white text-3xl font-black">{user.stats.gamesPlayed || 142}</p>
          <span className="text-xs text-green-500 font-bold">+3 this week</span>
        </div>
        <div className="bg-surface-dark rounded-xl p-6 border border-border-dark">
          <p className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-4">{t.profile.streak}</p>
          <p className="text-white text-3xl font-black">4 <span className="text-sm text-gray-500">Wins</span></p>
          <span className="text-xs text-orange-500 font-bold">Best: 12</span>
        </div>
        <div className="bg-surface-dark rounded-xl p-6 border border-border-dark">
          <p className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-4">{t.profile.avgTurns}</p>
          <p className="text-white text-3xl font-black">6.5</p>
          <span className="text-xs text-gray-500 font-bold">Top 15% Rank</span>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-white text-lg font-bold">{t.profile.history}</h3>
          <button className="text-primary text-sm font-bold">View All</button>
        </div>
        <div className="bg-surface-dark rounded-xl border border-border-dark overflow-hidden overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#1a0f0f] border-b border-border-dark">
              <tr>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-widest">{t.profile.result}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-widest">{t.profile.role}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-widest">{t.profile.opponent}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-widest">{t.profile.turns}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-widest text-right">{t.profile.date}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-dark">
              {mockHistory.map((item) => (
                <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className={`size-6 rounded-full flex items-center justify-center ${item.result === 'VICTORY' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                        <span className="material-symbols-outlined text-sm font-bold">
                          {item.result === 'VICTORY' ? 'check' : 'close'}
                        </span>
                      </div>
                      <span className="font-bold text-white">{item.result}</span>
                      <span className="text-gray-500 font-normal ml-1">{item.score}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${item.role.includes('Red') ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20'}`}>
                      {item.role}
                    </span>
                  </td>
                  <td className="p-4 text-gray-300">{item.opponent}</td>
                  <td className="p-4 text-gray-400">{item.turns} Turns</td>
                  <td className="p-4 text-right text-gray-500 text-xs">{item.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Profile;
