
import React, { useState } from 'react';
import { User } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface LobbyProps {
  user: User;
  onCreateGame: () => void;
  onJoinGame: (code: string) => void;
}

const Lobby: React.FC<LobbyProps> = ({ user, onCreateGame, onJoinGame }) => {
  const [code, setCode] = useState('');
  const { t } = useLanguage();

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      alert("Please enter a room code before joining.");
      return;
    }
    onJoinGame(code);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative">
      <div className="absolute -top-[20%] -right-[10%] w-[600px] h-[600px] rounded-full bg-primary/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[10%] -left-[10%] w-[400px] h-[400px] rounded-full bg-blue-600/5 blur-[100px] pointer-events-none" />
      
      <div className="w-full max-w-4xl mx-auto text-center mb-12 space-y-6 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold tracking-wider uppercase">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
          Competitive Grid Live
        </div>
        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white leading-[1.1]">
          {t.lobby.title} <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-600">{t.lobby.subtitle}</span>
        </h1>
        <p className="max-w-2xl mx-auto text-lg text-gray-400">
          {t.lobby.desc}
        </p>
      </div>

      <div className="w-full max-w-lg mx-auto bg-surface-dark border border-border-dark shadow-2xl rounded-2xl p-6 relative overflow-hidden group z-10">
        <div className="flex flex-col gap-6">
          <button 
            type="button"
            onClick={onCreateGame}
            className="w-full h-16 flex items-center justify-center gap-3 bg-primary hover:bg-primary-dark text-white rounded-xl shadow-lg shadow-primary/25 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
          >
            <span className="material-symbols-outlined text-3xl">add_circle</span>
            <span className="text-lg font-bold tracking-wide uppercase">{t.lobby.start}</span>
          </button>

          <div className="relative flex items-center py-2">
            <div className="flex-grow border-t border-border-dark"></div>
            <span className="flex-shrink-0 mx-4 text-gray-500 text-xs font-semibold uppercase tracking-widest">{t.lobby.joinTitle}</span>
            <div className="flex-grow border-t border-border-dark"></div>
          </div>

          <form 
            className="flex gap-2"
            onSubmit={handleJoinSubmit}
          >
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                <span className="material-symbols-outlined">vpn_key</span>
              </div>
              <input 
                className="block w-full h-12 pl-10 pr-3 rounded-lg bg-[#181111] border-border-dark text-white placeholder-gray-600 focus:border-primary focus:ring-primary transition-all font-medium tracking-wider uppercase"
                placeholder={t.lobby.joinPlaceholder}
                type="text"
                value={code}
                autoComplete="off"
                onChange={(e) => setCode(e.target.value)}
              />
            </div>
            <button 
              type="submit"
              className="px-6 h-12 bg-border-dark hover:bg-[#4d3636] text-white border border-border-dark rounded-lg font-bold text-sm tracking-wide uppercase transition-colors"
            >
              {t.lobby.joinButton}
            </button>
          </form>
        </div>
      </div>

      <div className="mt-16 w-full max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-6 relative z-10">
        <div className="bg-surface-dark p-6 rounded-xl border border-border-dark">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">{t.lobby.stats.matches}</p>
          <h3 className="text-3xl font-black text-white">12,405</h3>
          <div className="mt-2 text-xs text-green-500 flex items-center gap-1 font-bold">
            <span className="material-symbols-outlined text-[14px]">trending_up</span>
            +12% this week
          </div>
        </div>
        <div className="bg-surface-dark p-6 rounded-xl border border-border-dark">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">{t.lobby.stats.agents}</p>
          <h3 className="text-3xl font-black text-primary">842</h3>
          <div className="mt-2 text-xs text-gray-500 flex items-center gap-1 font-bold">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Live matches active
          </div>
        </div>
        <div className="bg-surface-dark p-6 rounded-xl border border-border-dark">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">{t.lobby.stats.servers}</p>
          <h3 className="text-3xl font-black text-white">156</h3>
          <div className="mt-2 text-xs text-gray-500 flex items-center gap-1 font-bold">
            <span className="material-symbols-outlined text-[14px]">public</span>
            Latency: 24ms
          </div>
        </div>
      </div>
    </div>
  );
};

export default Lobby;
