
import React, { useState, useEffect, useRef } from 'react';
import { GameState, Team, Role, Card, User, GameMessage, GameStatus, GamePlayer, BotDifficulty } from '../types';
import { geminiService } from '../services/geminiService';
import { multiplayerService } from '../services/multiplayerService';
import { useLanguage } from '../contexts/LanguageContext';

interface GameViewProps {
  game: GameState;
  user: User;
  onAction: (action: string, data: any) => void;
  onExit: () => void;
}

const GameView: React.FC<GameViewProps> = ({ game, user, onAction, onExit }) => {
  const [chatInput, setChatInput] = useState('');
  const [clueWord, setClueWord] = useState('');
  const [clueCount, setClueCount] = useState(1);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [isBotThinking, setIsBotThinking] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const { t, language } = useLanguage();

  const player = game.players.find(p => p.userId === user.id);
  const isSpymaster = player?.role === Role.SPYMASTER;
  const isMyTurn = game.turn === player?.team;

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [game.messages]);

  // Timer Logic
  useEffect(() => {
    const timer = setInterval(() => {
        if (game.isGameOver || !game.turnStartTime) {
            setTimeLeft(0);
            return;
        }

        const activeTeamPlayers = game.players.filter(p => p.team === game.turn);
        // Determine if it's currently a bot's specific move
        const role = game.lastClue ? Role.OPERATIVE : Role.SPYMASTER;
        const activePlayer = activeTeamPlayers.find(p => p.role === role);
        const isBotTurn = activePlayer?.isBot;

        const limit = isBotTurn ? 3 : 60; // 3 seconds for bots, 60s for humans
        const elapsed = Math.floor((Date.now() - game.turnStartTime) / 1000);
        const remaining = Math.max(0, limit - elapsed);
        
        setTimeLeft(remaining);

        // Note: We don't force end turn here from client side to avoid race conditions/multiple calls.
        // The bot logic below handles its own action timing.
    }, 100);

    return () => clearInterval(timer);
  }, [game.turnStartTime, game.turn, game.lastClue, game.players, game.isGameOver]);

  // --- BOT LOGIC (HOST ONLY) ---
  useEffect(() => {
    if (!multiplayerService.isHost || game.isGameOver || isBotThinking) return;

    const runBotTurn = async () => {
      const activeTeamPlayers = game.players.filter(p => p.team === game.turn);
      const spymaster = activeTeamPlayers.find(p => p.role === Role.SPYMASTER);
      const operative = activeTeamPlayers.find(p => p.role === Role.OPERATIVE) || activeTeamPlayers[0];

      // 1. Spymaster Turn
      if (!game.lastClue && spymaster?.isBot) {
        setIsBotThinking(true);
        // Bot thinks for 3 seconds before giving a clue
        await new Promise(r => setTimeout(r, 3000));
        
        try {
          // Pass the game language to Gemini so it generates clues in the correct language
          const hint = await geminiService.suggestClue(game.cards, game.turn, game.language);
          const cleanWord = hint.word.replace(/\s/g, '').substring(0, 10).toUpperCase();
          const cleanCount = Math.max(1, hint.count);
          onAction('GIVE_CLUE', { word: cleanWord, count: cleanCount });
        } catch (e) {
          onAction('GIVE_CLUE', { word: 'ERROR', count: 1 });
        }
        setIsBotThinking(false);
      }
      // 2. Operative Turn (Guessing)
      else if (game.lastClue && operative?.isBot) {
         const clue = game.lastClue;
         const allowed = clue.count + 1;
         
         if (game.guessesThisTurn >= allowed) {
           onAction('END_TURN', {});
           return;
         }

         setIsBotThinking(true);
         // Bot thinks for 3 seconds before guessing
         await new Promise(r => setTimeout(r, 3000));

         try {
           const guesses = await geminiService.guessCards(game.cards, clue.word, clue.count);
           
           const targetWord = guesses.find(g => {
             const card = game.cards.find(c => c.word.toUpperCase() === g.toUpperCase());
             return card && !card.isRevealed;
           });

           if (targetWord) {
             const cardToReveal = game.cards.find(c => c.word.toUpperCase() === targetWord.toUpperCase());
             if (cardToReveal) {
               onAction('REVEAL', { cardId: cardToReveal.id });
             } else {
               onAction('END_TURN', {});
             }
           } else {
             onAction('END_TURN', {});
           }
         } catch (e) {
           onAction('END_TURN', {});
         }
         setIsBotThinking(false);
      }
    };

    runBotTurn();
  }, [game.turn, game.lastClue, game.guessesThisTurn, game.isGameOver, game.cards]);

  const handleReveal = (card: Card) => {
    if (game.isGameOver || card.isRevealed || isSpymaster || !isMyTurn) return;
    onAction('REVEAL', { cardId: card.id });
  };

  const handleEndTurn = () => {
    if (!isMyTurn || isSpymaster) return;
    onAction('END_TURN', {});
  };

  const handleGiveClue = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanClue = clueWord.trim();
    if (!cleanClue || !isMyTurn || !isSpymaster) return;
    
    if (cleanClue.includes(' ')) {
      alert("Clue must be a single word!");
      return;
    }

    onAction('GIVE_CLUE', { word: cleanClue, count: clueCount });
    setClueWord('');
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput) return;
    const msg: GameMessage = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.username,
      senderRole: player?.role || Role.SPECTATOR,
      team: player?.team || undefined,
      text: chatInput,
      timestamp: Date.now()
    };
    onAction('SEND_MESSAGE', { message: msg });
    setChatInput('');
  };

  const getGeminiHint = async () => {
    if (!player?.team) return;
    setIsSuggesting(true);
    // Use the game's language for suggestions
    const hint = await geminiService.suggestClue(game.cards, player.team, game.language);
    const safeWord = hint.word.replace(/\s/g, '').substring(0, 10).toUpperCase();
    setClueWord(safeWord);
    setClueCount(hint.count);
    setIsSuggesting(false);
  };

  const getCardStyle = (card: Card) => {
    if (!card.isRevealed && !isSpymaster) return 'bg-[#2a1a1a] border-border-dark text-gray-400 hover:bg-[#3d2929]';
    switch (card.team) {
      case Team.RED: 
        return card.isRevealed
          ? 'bg-[#3f0707] text-red-200/30 border-[#2b0404] shadow-none grayscale-[0.3]' 
          : 'bg-primary text-white border-red-500 shadow-[0_4px_0_rgb(150,10,10)]';
      case Team.BLUE: 
        return card.isRevealed
          ? 'bg-[#0b1b36] text-blue-200/30 border-[#060e1d] shadow-none grayscale-[0.3]'
          : 'bg-blue-600 text-white border-blue-400 shadow-[0_4px_0_rgb(29,78,216)]';
      case Team.NEUTRAL: return 'bg-[#c2b59b] text-[#3d362a] border-[#a3977e] shadow-[0_4px_0_#8f8570]';
      case Team.ASSASSIN: return 'bg-gray-900 text-gray-300 border-gray-700 shadow-[0_4px_0_black]';
    }
  };

  return (
    <div className="flex flex-1 overflow-hidden h-full">
      <div className="flex-1 flex flex-col bg-[#0d0d0d] overflow-y-auto">
        <div className="w-full flex justify-center pt-6 pb-2 px-4 shrink-0">
          <div className="flex flex-col w-full max-w-5xl gap-4">
            <div className="flex items-center justify-between bg-surface-dark border border-border-dark rounded-xl p-4 shadow-2xl">
              <div className="flex items-center gap-4">
                <div className={`size-3 rounded-full ${game.turn === Team.RED ? 'bg-primary animate-pulse shadow-[0_0_10px_#ec1313]' : 'bg-primary/10'}`} />
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-red-500 font-black uppercase tracking-widest">{t.waiting.redTeam}</span>
                    {game.turn === Team.RED && !game.isGameOver && (
                      <span className="text-[10px] font-mono bg-red-900/50 text-red-300 px-1.5 rounded border border-red-800">{timeLeft}s</span>
                    )}
                  </div>
                  <span className="text-2xl font-black text-white">{game.redScore}<span className="text-gray-600 font-normal">/{game.totalRed}</span></span>
                </div>
              </div>
              <div className="flex flex-col items-center">
                <div className={`text-xs font-black uppercase tracking-widest mb-1 ${game.turn === Team.RED ? 'text-red-500' : 'text-blue-400'}`}>
                  {isBotThinking ? t.game.pending : t.game.intercepting}
                </div>
                <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-white italic">
                  {game.turn === Team.RED ? t.game.redTurn : t.game.blueTurn}
                </h1>
                {game.isGameOver && <div className="mt-2 px-4 py-1 bg-green-500/10 border border-green-500/30 text-green-500 font-black text-xs rounded uppercase tracking-widest animate-bounce">{t.game.victory}: {game.winner}</div>}
              </div>
              <div className="flex items-center justify-end gap-4 text-right">
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-2">
                    {game.turn === Team.BLUE && !game.isGameOver && (
                        <span className="text-[10px] font-mono bg-blue-900/50 text-blue-300 px-1.5 rounded border border-blue-800">{timeLeft}s</span>
                    )}
                    <span className="text-[10px] text-blue-400 font-black uppercase tracking-widest">{t.waiting.blueTeam}</span>
                  </div>
                  <span className="text-2xl font-black text-white">{game.blueScore}<span className="text-gray-600 font-normal">/{game.totalBlue}</span></span>
                </div>
                <div className={`size-3 rounded-full ${game.turn === Team.BLUE ? 'bg-blue-400 animate-pulse shadow-[0_0_10px_#137eec]' : 'bg-blue-400/10'}`} />
              </div>
            </div>
            {game.lastClue && (
              <div className="flex justify-center">
                <div className="bg-surface-dark border-b-4 border-primary/20 px-8 py-3 rounded-2xl flex items-center gap-6 shadow-xl">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{t.game.incoming}</span>
                    <span className="text-2xl font-black tracking-[0.2em] text-white uppercase">{game.lastClue.word}</span>
                  </div>
                  <div className="size-12 rounded-full bg-primary/10 border-2 border-primary flex items-center justify-center">
                    <span className="text-xl font-black text-primary">{game.lastClue.count}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="flex-1 p-4 md:p-8 flex justify-center items-start">
          <div className="w-full max-w-5xl grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4 relative">
             {/* Note: Blurry overlay for bots removed as requested */}
            {game.cards.map((card) => (
              <button
                key={card.id}
                onClick={() => handleReveal(card)}
                disabled={game.isGameOver || card.isRevealed || isSpymaster || !isMyTurn || isBotThinking}
                className={`aspect-[4/3] rounded-xl border-2 transition-all duration-300 flex flex-col items-center justify-center p-2 relative group overflow-hidden ${getCardStyle(card)} ${card.isRevealed ? 'opacity-90' : 'shadow-lg hover:scale-[1.03]'}`}
              >
                <p className={`text-sm md:text-base font-black tracking-widest z-10 text-center uppercase ${card.isRevealed && card.team === Team.NEUTRAL ? 'text-[#3d362a]' : 'text-white'}`}>{card.word}</p>
              </button>
            ))}
          </div>
        </div>
        <div className="shrink-0 pb-12 pt-4 flex justify-center w-full px-4 gap-4">
          {!isSpymaster && isMyTurn && !game.isGameOver && (
            <button onClick={handleEndTurn} disabled={isBotThinking} className="flex min-w-[240px] items-center justify-center rounded-2xl h-16 px-8 bg-primary hover:bg-primary-dark text-white text-xl font-black tracking-widest shadow-2xl transition-all uppercase disabled:opacity-50">{t.game.finalize}</button>
          )}
          {game.isGameOver && <button onClick={onExit} className="flex min-w-[240px] items-center justify-center rounded-2xl h-16 px-8 bg-surface-dark border border-border-dark text-white text-xl font-black tracking-widest uppercase shadow-2xl">{t.game.exit}</button>}
        </div>
      </div>
      <aside className="w-80 md:w-96 border-l border-border-dark bg-[#0a0a0a] flex flex-col shrink-0 hidden md:flex">
        <div className="p-4 bg-surface-dark border-b border-border-dark flex items-center justify-between">
          <span className="text-xs font-black text-gray-500 uppercase tracking-widest">{t.game.intel}</span>
          <div className="flex -space-x-2">
            {game.players.map(p => (
              <div key={p.userId} className={`size-6 rounded-full border-2 border-[#0a0a0a] bg-cover bg-center ${p.team === Team.RED ? 'ring-1 ring-red-500' : p.team === Team.BLUE ? 'ring-1 ring-blue-500' : ''}`} style={{ backgroundImage: `url(https://picsum.photos/seed/${p.userId}/50)` }} title={p.username} />
            ))}
          </div>
        </div>
        {isSpymaster && isMyTurn && !game.isGameOver && (
          <div className="p-6 border-b border-border-dark bg-[#1a0f0f]">
            <form onSubmit={handleGiveClue} className="space-y-4">
              <div className="flex flex-col gap-1">
                <input 
                  type="text" 
                  placeholder={t.game.cluePlaceholder}
                  value={clueWord} 
                  maxLength={10}
                  disabled={isBotThinking}
                  onChange={(e) => {
                    const val = e.target.value.toUpperCase().replace(/\s/g, ''); 
                    setClueWord(val);
                  }} 
                  className="w-full bg-[#111111] border-border-dark text-white rounded-xl px-4 py-3 text-sm font-bold uppercase tracking-widest focus:ring-primary focus:border-primary transition-all" 
                />
                <span className="text-[9px] text-gray-600 font-bold uppercase tracking-widest px-1">
                  {clueWord.length}/10 letters • No spaces allowed
                </span>
              </div>
              <div className="flex gap-2">
                <select value={clueCount} disabled={isBotThinking} onChange={(e) => setClueCount(Number(e.target.value))} className="bg-[#111111] border-border-dark text-white rounded-xl text-sm font-bold px-4 py-3">
                  {[1,2,3,4,5,6,7,8,9,0].map(n => <option key={n} value={n}>{n}</option>)}
                </select>
                <button type="submit" disabled={!clueWord || isBotThinking} className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-xl text-sm font-black flex-1 transition-all disabled:opacity-50 shadow-lg shadow-primary/20">{t.game.sendClue}</button>
              </div>
              <button type="button" onClick={getGeminiHint} disabled={isSuggesting || isBotThinking} className="w-full bg-blue-600/10 text-blue-400 border border-blue-600/20 px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all hover:bg-blue-600/20">
                <span className="material-symbols-outlined text-sm">rocket_launch</span>{isSuggesting ? t.game.decrypting : t.game.reqAnalysis}
              </button>
            </form>
          </div>
        )}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#080808]">
          {game.messages.map(msg => (
            <div key={msg.id} className={`flex flex-col ${msg.isSystem ? 'items-center text-center' : 'items-start'}`}>
              {msg.isSystem ? (
                <div className="bg-white/5 px-3 py-1 rounded-full border border-white/10 mb-2">
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{msg.text}</p>
                </div>
              ) : (
                <div className="flex gap-3 max-w-full">
                  <div className={`size-8 rounded-lg flex items-center justify-center shrink-0 border ${msg.team === Team.RED ? 'bg-red-900/20 border-red-500/30' : 'bg-blue-900/20 border-blue-500/30'}`}>
                    <span className={`text-xs font-black ${msg.team === Team.RED ? 'text-red-500' : 'text-blue-400'}`}>{msg.senderName[0].toUpperCase()}</span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-[9px] font-black text-gray-600 uppercase tracking-tighter mb-0.5">{msg.senderName} • {msg.senderRole}</span>
                    <p className="text-xs text-gray-300 break-words leading-relaxed">{msg.text}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <div className="p-4 border-t border-border-dark bg-surface-dark">
          <form onSubmit={handleSendMessage} className="relative flex items-center">
            <input type="text" placeholder={t.game.chatPlaceholder} value={chatInput} onChange={(e) => setChatInput(e.target.value)} className="w-full bg-[#111111] border-border-dark text-white text-xs rounded-xl pl-4 pr-10 py-3 focus:border-primary font-medium" />
            <button type="submit" className="absolute right-3 text-gray-500 hover:text-primary transition-colors"><span className="material-symbols-outlined text-lg">arrow_forward</span></button>
          </form>
        </div>
      </aside>
    </div>
  );
};

export default GameView;
