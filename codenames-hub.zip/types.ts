
export enum Team {
  RED = 'RED',
  BLUE = 'BLUE',
  NEUTRAL = 'NEUTRAL',
  ASSASSIN = 'ASSASSIN'
}

export enum Role {
  SPYMASTER = 'SPYMASTER',
  OPERATIVE = 'OPERATIVE',
  SPECTATOR = 'SPECTATOR'
}

export enum BotDifficulty {
  NOVICE = 'NOVICE',
  AGENT = 'AGENT',
  ELITE = 'ELITE'
}

export enum GameStatus {
  LOBBY = 'LOBBY',
  PLAYING = 'PLAYING',
  ENDED = 'ENDED'
}

export interface User {
  id: string;
  username: string;
  email: string;
  level: number;
  stats: UserStats;
}

export interface UserStats {
  wins: number;
  losses: number;
  gamesPlayed: number;
  winStreak: number;
  bestStreak: number;
  avgRoundsPerWin: number;
}

export interface MatchHistoryItem {
  id: string;
  result: 'VICTORY' | 'DEFEAT';
  score: string;
  role: string;
  opponent: string;
  turns: number;
  date: string;
}

export interface Card {
  id: string;
  word: string;
  team: Team;
  isRevealed: boolean;
}

export interface GameMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: Role;
  team?: Team;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

export interface GameState {
  roomId: string;
  roomCode: string;
  status: GameStatus;
  cards: Card[];
  turn: Team;
  turnStartTime?: number;
  winner: Team | null;
  redScore: number;
  blueScore: number;
  totalRed: number;
  totalBlue: number;
  players: GamePlayer[];
  messages: GameMessage[];
  lastClue?: {
    word: string;
    count: number;
  };
  guessesThisTurn: number;
  isGameOver: boolean;
  creatorId: string;
  language: 'en' | 'ckb';
}

export interface GamePlayer {
  userId: string;
  username: string;
  team: Team | null;
  role: Role;
  isReady: boolean;
  isBot?: boolean;
  botDifficulty?: BotDifficulty;
}

export type SyncMessage = 
  | { type: 'STATE_UPDATE', payload: GameState }
  | { type: 'PLAYER_ACTION', payload: { action: string, data: any, userId: string } };
