
export type Language = 'en' | 'ckb';

export const translations = {
  en: {
    navbar: {
        title: "CODENAMES HUB",
        lobby: "Lobby",
        profile: "Profile"
    },
    login: { title: "Agent Login", button: "Enter Hub", placeholder: "Email address", connecting: "Establishing Uplink..." },
    lobby: {
      title: "The Competitive Edge",
      subtitle: "For Codenames.",
      desc: "Join the premier platform for professional deductive play.",
      start: "Start New Game",
      joinTitle: "Or join existing",
      joinPlaceholder: "Enter Room Code",
      joinButton: "Join",
      stats: { matches: "Total Matches", agents: "Agents Online", servers: "Global Servers" }
    },
    waiting: {
      title: "Mission Lobby",
      code: "Infiltration Code",
      ready: "Ready for Action",
      markReady: "Mark as Ready",
      startGame: "Initialize Grid",
      needSpy: "Need Spymasters",
      addBot: "Add Bot",
      maxBots: "Max Bots",
      redTeam: "Red Team",
      blueTeam: "Blue Team",
      joinSpy: "Join Spymaster",
      joinOp: "Join Operative",
      unassigned: "Unassigned Observers"
    },
    game: {
      redTurn: "RED TURN",
      blueTurn: "BLUE TURN",
      victory: "Victory",
      pending: "Agent Decision Pending...",
      intercepting: "Intercepting Signal",
      incoming: "Incoming Clue",
      finalize: "Finalize Turn",
      exit: "Exit to Hub",
      intel: "Agent Intel",
      chatPlaceholder: "Communicate with team...",
      cluePlaceholder: "Single word clue...",
      sendClue: "Send Clue",
      decrypting: "Decrypting...",
      reqAnalysis: "Request AI Analysis",
      waitingHost: "Awaiting Uplink from Host",
      sync: "Synchronizing Intelligence..."
    },
    profile: {
      winRate: "Win Rate",
      gamesPlayed: "Games Played",
      streak: "Current Streak",
      avgTurns: "Avg Turns / Win",
      history: "Match History",
      edit: "Edit Profile",
      result: "Result",
      role: "Role",
      opponent: "Opponent",
      turns: "Turns",
      date: "Date"
    }
  },
  ckb: {
    navbar: {
        title: "یاری کۆدنەیم",
        lobby: "ژوور",
        profile: "پڕۆفایل"
    },
    login: { title: "چوونەژووری ئەندام", button: "چوونە ناوەند", placeholder: "ناونیشانی ئیمەیڵ", connecting: "پەیوەستبوون بە سێرڤەر..." },
    lobby: {
      title: "پێگەی پێشبڕکێ",
      subtitle: "بۆ کۆدناوەکان.",
      desc: "بەشداری بکە لە باشترین سەکۆ بۆ یاری کردنی پیشەگەرانە.",
      start: "دەستپێکردنی یاری نوێ",
      joinTitle: "یان بەشداری یاری هەبوو بە",
      joinPlaceholder: "کۆدی ژوور بنووسە",
      joinButton: "بەشداری",
      stats: { matches: "کۆی یارییەکان", agents: "ئەندامەکان ئۆنلاین", servers: "سێرڤەرە جیهانییەکان" }
    },
    waiting: {
      title: "ژووری ئامادەباشی",
      code: "کۆدی نهێنی",
      ready: "ئامادەم بۆ چالاکی",
      markReady: "خۆم ئامادەکەم",
      startGame: "دەستپێکردنی یاری",
      needSpy: "پێویستی بە سیخوڕە",
      addBot: "زیادکردنی بۆت",
      maxBots: "زۆرترین بۆت",
      redTeam: "تیمی سوور",
      blueTeam: "تیمی شین",
      joinSpy: "بوون بە سیخوڕ",
      joinOp: "بوون بە بریکار",
      unassigned: "چاودێرەکان"
    },
    game: {
      redTurn: "نۆرەی سوور",
      blueTurn: "نۆرەی شین",
      victory: "سەرکەوتن",
      pending: "چاوەڕوانی بڕیاری بریکار...",
      intercepting: "وەرگرتنی سیگناڵ",
      incoming: "زانیاری هاتوو",
      finalize: "کۆتایی هێنان بە تۆرە",
      exit: "دەرچوون بۆ ناوەند",
      intel: "زانیاری بریکار",
      chatPlaceholder: "پەیوەندی لەگەڵ تیم...",
      cluePlaceholder: "وشەیەک وەک سەرەداو...",
      sendClue: "ناردنی سەرەداو",
      decrypting: "شیکارکردن...",
      reqAnalysis: "داواکاری شیکاری AI",
      waitingHost: "چاوەڕوانی پەیوەندی خانەخوێ",
      sync: "هاوکاتکردنی زانیاری..."
    },
    profile: {
      winRate: "ڕێژەی سەرکەوتن",
      gamesPlayed: "یاری ئەنجامدراو",
      streak: "زنجیرەی سەرکەوتن",
      avgTurns: "نێوەندی تۆرەکان",
      history: "مێژووی یارییەکان",
      edit: "دەستکاری پرۆفایل",
      result: "ئەنجام",
      role: "ڕۆڵ",
      opponent: "رکابەر",
      turns: "تۆرەکان",
      date: "بەروار"
    }
  }
};
